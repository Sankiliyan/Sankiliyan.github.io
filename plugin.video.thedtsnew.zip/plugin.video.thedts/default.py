import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon,os

addon = xbmcaddon.Addon(id='plugin.video.thedts')

ADDON = xbmcaddon.Addon()
website = 'http://floppi.org/xbmc/'


xxx=addon.getSetting("xxx")
oldview=addon.getSetting("oldview")

if xxx=="true":
  xxx=True
else:
  xxx=False

if oldview=="true":
  oldview=True
else:
  oldview=False


def NEWVIEW():
    if xxx==True:
        addDir('Alle',website + 'alle.php',1,'')
        addDir('Danske',website + 'dansk.php',1,'')
        addDir('Svensk & Norsk',website + 'norsk.php',1,'')
        addDir('Engelsk',website + 'engelsk.php',1,'')
        addDir('XXX',website + 'xxx.php',1,'')
    else:
        addDir('Alle',website + 'alle.php',1,'')
        addDir('Danske',website + 'dansk.php',1,'')
        addDir('Svensk & Norsk',website + 'norsk.php',1,'')
        addDir('Engelsk',website + 'engelsk.php',1,'')


def OLDVIEW():
    if xxx==True:
        INDEX(website + 'channels.html')
    else:
        INDEX(website + 'channels2.html')


def INDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('href="(.+?)">(.+?)</a>').findall(link)
        for url,name in match:
                addLink(name,url,'')


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addLink(name,url,iconimage):
        ok=True

        iconImage = os.path.join(ADDON.getAddonInfo('path'),"channels/" + name + ".png")
        if not os.path.exists(iconImage):
            iconImage = os.path.join(ADDON.getAddonInfo('path'),"channels/" + 'noimage.png')

        liz=xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('IsPlayable', 'true')
        user_agent = "|User-Agent=" + urllib.quote("http-user-agent=Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5355d Safari/8536.25")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url + user_agent,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):

        iconImage = os.path.join(ADDON.getAddonInfo('path'),"category/" + name + ".png")

        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        user_agent = "|User-Agent=" + urllib.quote("http-user-agent=Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5355d Safari/8536.25")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u + user_agent,listitem=liz,isFolder=True)
        return ok


params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        if oldview==True:
            OLDVIEW()
        else:
            NEWVIEW()
       
elif mode==1:
        print ""+url
        INDEX(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
